/*------------公共脚本部分----------*/

/*获取随机字符串*/
function getRndCharNum(num) {
	var rmstr="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	var re="";
	for (i = 0; i <= num; i++) {
		var start=Math.floor(Math.random() * rmstr.length  + 1)-1;
		re=re+rmstr.substr(start,1);
		}
	return re;
}
/*url 前加上http://*/
function  addHttp(url){
		if (url.substr(0,7)!="http://"){
			if (url.substr(0,8)!="https://"){
				return "http://" +url;
			}
		}
		return url;
	}
/*获取经过混淆的referrer 解决IE升级后不能重复访问同一地址的问题*/
function getGBReferer(){
	var referrer=getReferer();
	if (referrer==""){
		return "about:blank";
	}else{
		if (referrer.indexOf("?")>0){
			referrer=referrer+"&"+getRndCharNum(10)+"="+getRndCharNum(10);
		}else{
			referrer=referrer+"?"+getRndCharNum(10)+"="+getRndCharNum(10);
		}
		return addHttp(referrer);
	}
}

function getReferer(){
		var f = "";//来源页面 		
		if (document["referrer"] != null)  
		  f = document.referrer; 		
		// convert all the unknown's into blank 
		if ((f == "") || (f == "[unknown origin]") || (f == "unknown") || (f == "undefined")) 
		f = ""; 
		//如果是测试的话默认设置来源为网易
		if (getArgs("greatbitdebug")=="true")
			f="http://www.163.com";
return f;
}
/*获取当前页的参数*/
function getArgs(sArgName){
	return getArgsFromHref(window.location.toString(),sArgName);
}
/*获取根据url获取参数*/
function getArgsFromHref(sHref, sArgName) 
　　{ 
　　var args = sHref.split("?"); 
　　var retval = ""; 
　　if(args[0] == sHref) /*参数为空*/ 
　　{ 
　　return retval; /*无需做任何处理*/ 
　　} 
　　var str = args[1]; 
　　args = str.split("&"); 
　　for(var i = 0; i < args.length; i ++) 
　　{ 
　　str = args[i]; 
　　var arg = str.split("="); 
　　if(arg.length <= 1) continue; 
　　if(arg[0] == sArgName) retval = arg[1]; 
　　} 
　　return retval; 
}



/*获取随机字符串*/
function getRndCharNum(num) {
	var rmstr="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	var re="";
	for (i = 0; i <= num; i++) {
		var start=Math.floor(Math.random() * rmstr.length  + 1)-1;
		re=re+rmstr.substr(start,1);
		}
	return re;
}
function IsNumber(str) 
{ 
	var nonDigit = /\D{1,}/; 
	return (!nonDigit.test(str));
}

/*function IsIP(str)
{
	var ip = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
	return (ip.test(str));
}*/

function IsIP(s){
 var check=function(v){try{return (v<=255 && v>=0)}catch(x){return false}};
 var re=s.split(".")
 return (re.length==4)?(check(re[0]) && check(re[1]) && check(re[2]) && check(re[3])):false
}

function IsURL(str)
{
	var url =/^(http\:\/\/)?\w+([\.-]?\w+)*(\.\w{2,3})+(.)*$/;
	return (url.test(str)); 		
}

function IsInteger(str) 
{ 
   for(var i=0;i<str.length;i++){
	  if (str.charAt(i) in ['0','1','2','3','4','5','6','7','8','9']){
	  }else{
		return false;	  
	  }
   }
   return true;
}
var Browser = { 
'isIE' : (navigator.userAgent.indexOf('MSIE') >= 0) && (navigator.userAgent.indexOf('Opera') < 0), 
'isFirefox' : navigator.userAgent.indexOf('Firefox') >= 0, 
'isOpera' : navigator.userAgent.indexOf('Opera') >= 0 
}; 


/*设置Cookie*/
function SetCookie (name, value) { 
var argv = SetCookie.arguments; 
var argc = SetCookie.arguments.length; 
var expires = (argc > 2) ? argv[2] : null; 
var path = (argc > 3) ? argv[3] : null; 
var domain = (argc > 4) ? argv[4] : null; 
var secure = (argc > 5) ? argv[5] : false; 
document.cookie = name + "=" + escape (value) + 
((expires == null) ? "" : ("; expires=" + expires.toGMTString())) + 
((path == null) ? "" : ("; path=" + path)) + 
((domain == null) ? "" : ("; domain=" + domain)) + 
((secure == true) ? "; secure" : "");
}
/*获取Cookie*/
function getCookieVal(offset) {
var endstr = document.cookie.indexOf (";", offset);
if (endstr == -1)
endstr = document.cookie.length;
return unescape(document.cookie.substring(offset, endstr));
}
/*获取Cookie*/
function GetCookie (name) { 
	var arg = name + "="; 
	var alen = arg.length; 
	var clen = document.cookie.length; 
	var i = 0; 
	while (i < clen) { 
		var j = i + alen; 
		if (document.cookie.substring(i, j) == arg) 
			return getCookieVal (j); 
		i = document.cookie.indexOf(" ", i) + 1; 
		if (i == 0) break; 
	} 
	return null;
}

/*删除Cookie*/
function DeleteCookie (name) { 
var exp = new Date(); 
exp.setTime (exp.getTime() - 1); 
// This cookie is history 
var cval = 0; 
document.cookie = name + "=" + cval + "; expires=" + exp.toGMTString();
}