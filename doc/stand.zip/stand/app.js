﻿window.onresize = resize_wm;
window.onerror = function(){}

var divTop,divLeft,divWidth,divHeight,docHeight,docWidth,objTimer,mytm,i = 0;

function getMsg()
{
try
{
divTop = parseInt(document.getElementById("ctpop").style.top,10)
divLeft = parseInt(document.getElementById("ctpop").style.left,10)
divHeight = parseInt(document.getElementById("ctpop").offsetHeight,10)
divWidth = parseInt(document.getElementById("ctpop").offsetWidth,10)
docWidth = document.body.clientWidth;
docHeight = document.body.clientHeight;
document.getElementById("ctpop").style.top = parseInt(document.body.scrollTop,10) + docHeight + 10;// divHeight
document.getElementById("ctpop").style.left = parseInt(document.body.scrollLeft,10) + docWidth - divWidth
document.getElementById("ctbody").style.visibility="visible"
objTimer = window.setInterval("move_wm()",12)
autocls()
}
catch(e){}
}


function resize_wm()
{
i+=1
try
{
divHeight = parseInt(document.getElementById("ctpop").offsetHeight,10)
divWidth = parseInt(document.getElementById("ctpop").offsetWidth,10)
docWidth = document.body.clientWidth;
docHeight = document.body.clientHeight;
document.getElementById("ctpop").style.top = docHeight - divHeight + parseInt(document.body.scrollTop,10)
document.getElementById("ctpop").style.left = docWidth - divWidth + parseInt(document.body.scrollLeft,10)
}
catch(e){}
}


function move_wm()
{
try
{
if (parseInt(document.getElementById("ctpop").style.top,10) <= (docHeight - divHeight + parseInt(document.body.scrollTop,10)))
{
window.clearInterval(objTimer)
objTimer = window.setInterval("resize_wm()",1)
}
divTop = parseInt(document.getElementById("ctpop").style.top,10)
document.getElementById("ctpop").style.top = divTop - 1
}
catch(e){}
}

function close_wm()
{
document.getElementById('ctpop').style.visibility='hidden';
document.getElementById('ctbody').style.visibility='hidden';
document.getElementById('opwm').style.visibility='hidden';
if(objTimer) window.clearInterval(objTimer);
}

function mini_wm() 
{
document.getElementById('ctbody').style.visibility='hidden';
document.getElementById("opwm").style.visibility="visible";
document.getElementById("ctpop").style.bottom="0";
}

function reop_wm(){
document.getElementById("opwm").style.visibility="hidden";
document.getElementById('ctbody').style.visibility='visible';
//alert(document.getElementById("ctpop").style.top);
} 

function hold_wm()
{
if(mytm) clearTimeout(mytm);
}

function autocls()
{
mytm=setTimeout("mini_wm()",30000);
}





document.write("<DIV id=ctpop style='LEFT: 0px; VISIBILITY: visible; WIDTH: "+page_w+"px; POSITION: absolute; TOP: 0px; HEIGHT: 206px;' onmouseover='hold_wm()' onmouseout='autocls()' oncontextmenu='self.event.returnValue=false'>");
document.write("<div id=opwm style='position:relative; VISIBILITY: hidden;left:0px; top:"+(page_h+28)+"px; height:26px; width:"+page_w+"px;'>");
document.write("<table style='width: "+page_w+"px; height: 26px;border: 1px solid #999999;' cellspacing='0' cellpadding='0'>");
document.write("	<tr>");
document.write("		<td style='height: 26px;background-image: url(images/th_bg.gif);'><table width='"+page_w+"' height='26' border='0' cellpadding='0' cellspacing='0'>");
document.write("	<tr>");
document.write("		<td>");
document.write("			<img src='images/logo_tit.gif' width='"+(page_w-35)+"'  height='26' alt='展开' onClick='reop_wm()' style='cursor:hand;'/></td>");
document.write("		<td width='16' height='26'></td>");
document.write("		<td width='*' height='26' style='text-align: right;'><table width='35' border='0' cellspacing='0' cellpadding='0'>");
document.write("              <tr>");
document.write("                <td><img src='images/open.gif' width='15' height='15' onClick='reop_wm()' style='cursor:hand;' alt='展开'/></td>");
document.write("                <td width='5'></td>");
document.write("                <td><img src='images/close.gif' width='15' height='15' onClick='close_wm()' style='cursor:hand;' alt='隐藏'/></td>");
document.write("              </tr>");
document.write("            </table></td>");
document.write("	</tr>");
document.write("</table>");
document.write("</td>");
document.write("</tr>");
document.write("</table>");
document.write("</div>");
document.write("<DIV id=ctbody style='LEFT: 0px; VISIBILITY: hidden; WIDTH: "+page_w+"px; POSITION: relative; TOP: 0px; HEIGHT: "+(page_h+26)+"px;'>");
document.write("<table style='width: "+page_w+"px; height: "+(page_h+26)+"px;border: 1px solid #999999;' cellspacing='0' cellpadding='0'>");
document.write("	<tr>");
document.write("		<td style='height: 26px;background-image: url(images/th_bg.gif);'><table width="+page_w+" height='26' border='0' cellpadding='0' cellspacing='0'>");
document.write("	<tr>");
document.write("		<td>");
document.write("			<img src='images/logo_tit.gif' width='"+(page_w-35)+"' height='26' alt='关闭' onClick='mini_wm()' style='cursor:hand;' border='0'/></td>");
document.write("		<td width='16' height='26'></td>");
document.write("		<td width='*' height='26' style='text-align: right;'><table width='35' border='0' cellspacing='0' cellpadding='0'>");
document.write("              <tr>");
document.write("                <td><img src='images/mini.gif' width='15' height='15' onClick='mini_wm()' style='cursor:hand;' alt='关闭'/></td>");
document.write("                <td width='5'></td>");
document.write("                <td><img src='images/close.gif' width='15' height='15' onClick='close_wm()' style='cursor:hand;' alt='隐藏'/></td>");
document.write("              </tr>");
document.write("            </table></td>");
document.write("	</tr>");
document.write("</table>");
document.write("</td>");
document.write("	</tr>");
document.write("	<tr>");
document.write("		<td style='height:"+page_h+"px;'><iframe src='page.html' width='"+page_w+"' height='"+page_h+"' target='_blank' allowTransparency='true' marginWidth='0' marginHeight='0' frameBorder='0' scrolling='no' ></iframe></td>");
document.write("	</tr>");
document.write("</table>");
document.write("</DIV>");
document.write("</DIV>");



setTimeout("getMsg();",1000);